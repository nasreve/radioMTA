import 'package:flutter/material.dart';
import 'package:radiomta/pages/detail_page.dart';
import 'package:radiomta/theme.dart';
import 'package:radiomta/models/profile.dart';

class ProfileCard extends StatelessWidget {
      final Profile profile;

      ProfileCard(this.profile);
      
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(builder: (context) => DetailPage(),
        ),);
      },
          child: ClipRRect(
         borderRadius: BorderRadius.circular(18),
         child: Container(
          height: 150,
          width: 120,
          color: Color(0xffF6F7F8),
          child: Column(
            children: [
              Stack(
                children: [
                  Image.asset(
                    profile.imageUrl,
                    width: 120,
                    height: 102,
                    fit: BoxFit.cover,
                  ),
                  profile.isPopular ?
                  Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            width: 50,
                            height: 30,
                            decoration: BoxDecoration(
                              color: blueColor,
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(36),
                              ),
                            ),
                            child: Center(
                              child: Image.asset(
                                'assets/icon_star.png',
                                width: 22,
                                height: 22,
                              ),
                            ),
                          ),
                        )
                          :Container()
                ],
              ),
              SizedBox(
                    height: 11,
                  ),
                  Text(
                    profile.name,
                    style: blackTextStyle.copyWith(
                    fontSize:16,
                    ),
                  )
            ],
          ),
         ),


          ),
    );
  }
}