import 'package:flutter/material.dart';
import 'package:radiomta/models/live.dart';
import 'package:radiomta/theme.dart';

class LiveCard extends StatelessWidget {
  final Live live;

  LiveCard(this.live);

  @override
  Widget build(BuildContext context) {
    return Row(
    children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(18),
          child: Container(
          height: 110,
          width: 130,
          child: Stack(
            children: [
              Image.asset(
                live.imageUrl,
                ),
            ],

          ),

        ),
      ),
      SizedBox(
        width : 20,
      ),

      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(live.name,
          style: blackTextStyle.copyWith(
            fontSize: 18,
          ),
          ),
          SizedBox(
            height:2,
          ),
          Text.rich(
            TextSpan(text: live.ket,
            style: blackTextStyle.copyWith(
              fontSize: 16,
            ),
            ),
            ),
        ],
      ),
    ],  
    );
  }
}