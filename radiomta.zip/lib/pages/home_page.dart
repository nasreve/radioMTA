import 'package:flutter/material.dart';
import 'package:radiomta/models/live.dart';
import 'package:radiomta/models/profile.dart';
import 'package:radiomta/theme.dart';
import 'package:radiomta/widgets/bottom_navbar_item.dart';
import 'package:radiomta/widgets/live_card.dart';
import 'package:radiomta/widgets/profile_card.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
      return Scaffold(
      backgroundColor : whiteColor,
      body: SafeArea(
        bottom: false,
                child: ListView(
          children: [
            SizedBox(
              height: edge,
            ),
            // NOTE: TITLE/HEADER
            Padding(
              padding: EdgeInsets.only(left: edge),
              child: Text(
                'Radio jaringan',
                style: blackTextStyle.copyWith(
                  fontSize: 24,
                ),
              ),
            ),
            SizedBox(
              height: 2,
            ),
            Padding(
              padding: EdgeInsets.only(left: edge),
              child: Text(
                'Profil & Live Streaming',
                style: greyTextStyle.copyWith(
                  fontSize: 16,
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            // NOTE: PROFIL
            Padding(
              padding: EdgeInsets.only(left: edge),
              child: Text(
                'Profil Radio',
                style: regularTextStyle.copyWith(
                  fontSize: 16,
                ),
              ),
            ),
            SizedBox(
              height: 16,
            ),
            Container(
              height: 150,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  SizedBox(
                    width:24,
                  ),
                  ProfileCard(
                    Profile(id: 1,
                    name: 'Purbowangi',
                    imageUrl: 'assets/city1.png',),
                   ),
                  SizedBox(width:20,
                  ),
                  ProfileCard(Profile(id: 2,
                    name: 'Kharisma',
                    imageUrl: 'assets/city2.png',),
                   ),
                  SizedBox(width:20,
                  ),
                  ProfileCard(Profile(id: 3,
                    name: 'Prima',
                    imageUrl: 'assets/city3.png',),
                   ),
                  SizedBox(width:20,
                  ),
                  ProfileCard(Profile(id: 4,
                  name: 'Persada',
                  imageUrl: 'assets/city4.png',
                  isPopular: true),
                  ),
                  SizedBox(width:20,
                  ),
                  ProfileCard(Profile(id: 5,
                  name: 'Ash Shidiq',
                  imageUrl: 'assets/city5.png',),
                  ),
                  SizedBox(width:20,
                  ),
                  ProfileCard(Profile(id: 6,
                  name: 'Pantura',
                  imageUrl: 'assets/city6.png',),
                  ),
                  SizedBox(width:20,
                  ),
            ],
            ),
          ),
          SizedBox(
            height:20,
          ),
          // NOTE : LIVE STREAMING
              Padding(
              padding: EdgeInsets.only(left: edge),
              child: Text(
                'Link Eksternal',
                style: blackTextStyle.copyWith(
                  fontSize: 16,
                ),
              ),
            ),
            SizedBox(
              height:14
            ),
            Padding(padding: EdgeInsets.symmetric(horizontal: edge,),

              child: Column(
                children: [
                  LiveCard(
                    Live(id: 1, name: 'Live Streaming', imageUrl: 'assets/streaming.png', ket: 'MTATV',),
                  ),
                  SizedBox(height:20,),
                  LiveCard(
                    Live(id: 2, name: 'Download mp3', imageUrl: 'assets/mp3.png', ket: 'Jihad Pagi',),
                  ),
                  SizedBox(height:20,),
                  LiveCard(
                    Live(id: 3, name: 'Download Brosur', imageUrl: 'assets/brosur.png', ket: 'Jihad Pagi',),
                  ),
                  SizedBox(height:20,),
                ],
              ),

            ),
                 SizedBox(
                   height:50 + edge
                 ),
          ],
          
      ),

      ),
      
        floatingActionButton: Container(
        height: 65,
        width: MediaQuery.of(context).size.width - (2 * edge),
        margin: EdgeInsets.symmetric(
          horizontal: edge,
        ),
        decoration: BoxDecoration(
          color: Color(0xffF6F7F8),
          borderRadius: BorderRadius.circular(23),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            BottomNavbarItem(
              imageUrl: 'assets/icon_home.png',
              isActive: true,
            ),
            BottomNavbarItem(
              imageUrl: 'assets/icon_email.png',
              isActive: false,
            ),
            BottomNavbarItem(
              imageUrl: 'assets/icon_card.png',
              isActive: false,
            ),
            BottomNavbarItem(
              imageUrl: 'assets/icon_love.png',
              isActive: false,
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      );
  }
}