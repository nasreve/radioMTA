class Profile{
  int id;
  String name;
  String imageUrl;
  bool isPopular;

  Profile({this.id, this.name, this.imageUrl, this.isPopular = false});
}