class Live{
  int id;
  String name;
  String ket;
  String imageUrl;

  Live({this.id, this.name, this.ket, this.imageUrl});
}
