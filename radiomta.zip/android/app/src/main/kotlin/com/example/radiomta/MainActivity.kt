package com.example.radiomta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
